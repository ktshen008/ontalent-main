/**
 * OnTalent — submission endpoint (group orders + workshop applications)
 * ------------------------------------------------------------------
 * This is an UPDATE to the script you already deployed for the goBILDA
 * group order. It now handles two kinds of submission, chosen by the
 * "type" field the form sends:
 *
 *   (no type) or "order"  ->  goBILDA group order   (Order Lines + Orders tabs)
 *   "workshop"            ->  workshop application   (Workshop Applications tab)
 *
 * HOW TO UPDATE (no new authorization needed):
 *   1. Open the SAME Google Sheet + Apps Script project you deployed before.
 *   2. Select all the old code, delete it, paste this whole file in, Save.
 *   3. Deploy > Manage deployments > (pencil/edit your web app) >
 *      Version: New version > Deploy.
 *   4. Keep the SAME web app URL — put it in BOTH forms' CONFIG.submitEndpoint.
 *
 * The order form keeps working unchanged (it sends no "type", so it
 * falls through to the order handler). The Workshop Applications tab is
 * created automatically on the first workshop submission.
 * ------------------------------------------------------------------
 */

// Get an email for every submission. Set to "" to turn off.
var NOTIFY_EMAIL = "info@ontalent.org";
// Email the person a confirmation copy of what they sent.
var SEND_CONFIRMATION = true;

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    if (data.company) { return ok_(); }              // honeypot: ignore bots
    if (data.type === "workshop") { return handleWorkshop_(data); }
    return handleOrder_(data);                        // default = group order
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/* ---------------- Workshop applications ---------------- */
function handleWorkshop_(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName("Workshop Applications") || ss.insertSheet("Workshop Applications");
  if (sh.getLastRow() === 0) {
    sh.appendRow(["Submitted", "Status", "Name", "Role", "Email", "Phone",
      "Sponsor name", "Sponsor role", "Sponsor email",
      "School", "School type", "City", "Board",
      "Pathways", "Grades", "# students", "Format", "Location", "Timeframe",
      "Space/equipment", "Goals", "Funding", "Notes"]);
  }
  sh.appendRow([new Date(), "New", data.name, data.role, data.email, data.phone,
    data.sponsorName, data.sponsorRole, data.sponsorEmail,
    data.school, data.schoolType, data.city, data.board,
    data.pathways, data.grades, data.students, data.format, data.location, data.timeframe,
    data.space, data.goals, data.funding, data.notes]);

  if (NOTIFY_EMAIL) {
    MailApp.sendEmail(NOTIFY_EMAIL, "New OnTalent workshop application — " + data.school, data.summary);
  }
  if (SEND_CONFIRMATION && data.email) {
    MailApp.sendEmail(data.email, "Your OnTalent workshop application",
      "Thanks, " + data.name + " — we've received your request and will follow up.\n\n" + data.summary);
  }
  return ok_();
}

/* ---------------- goBILDA group order (unchanged) ---------------- */
function handleOrder_(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var orderId = "GB-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd-HHmmss");

  var lines = ss.getSheetByName("Order Lines") || ss.insertSheet("Order Lines");
  if (lines.getLastRow() === 0) {
    lines.appendRow(["Submitted", "Order ID", "Name", "Email", "Phone", "Team",
      "Fulfillment", "Address", "Postal", "Part #", "Product", "Qty", "Unit price", "Line total", "Notes"]);
  }
  var items = data.items || [];
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    lines.appendRow([new Date(), orderId, data.name, data.email, data.phone, data.team,
      data.fulfillment, data.address, data.postal,
      it.partNo, it.name, it.qty, it.price, it.lineTotal, data.notes]);
  }

  var orders = ss.getSheetByName("Orders") || ss.insertSheet("Orders");
  if (orders.getLastRow() === 0) {
    orders.appendRow(["Submitted", "Order ID", "Name", "Email", "Phone", "Team",
      "Fulfillment", "Postal", "# items", "Subtotal", "Shipping", "Total", "Currency", "Status", "Notes"]);
  }
  orders.appendRow([new Date(), orderId, data.name, data.email, data.phone, data.team,
    data.fulfillment, data.postal, items.length, data.subtotal, data.shipping, data.total,
    data.currency, "New", data.notes]);

  if (NOTIFY_EMAIL) {
    MailApp.sendEmail(NOTIFY_EMAIL, "New goBILDA group order — " + data.name, data.summary);
  }
  if (SEND_CONFIRMATION && data.email) {
    MailApp.sendEmail(data.email, "Your goBILDA group order — " + data.org,
      "Thanks, " + data.name + " — your order is in.\n\n" + data.summary);
  }
  return ok_();
}

/* ---------------- For testing: run this once to authorize ---------------- */
function authorize() {
  SpreadsheetApp.getActiveSpreadsheet().getName();
  MailApp.getRemainingDailyQuota();
}

function ok_() {
  return ContentService.createTextOutput(JSON.stringify({ ok: true }))
    .setMimeType(ContentService.MimeType.JSON);
}
